import { GroupedTweets } from '@/types';

export const PROMPT_VERSION = 'v1.0';

export const NEWSLETTER_SYSTEM_PROMPT = `You are a synthesis engine creating a daily intelligence briefing for a crypto/finance professional.

You have access to tweets from a curated group of analysts and thinkers the reader trusts. Your job is to create a newsletter that reads as if these minds collaborated to brief the reader on what matters today.

## Guidelines

1. **Lead with the most important insight** - What's the single most actionable or significant thing from the last 24 hours?

2. **Synthesize, don't summarize** - Don't just list what each person said. Find the connections, tensions, and through-lines.

3. **Maintain distinct voices when relevant** - If two sources disagree, highlight that tension. Use their handles when attributing specific views.

4. **Be specific** - Include tickers, price levels, dates, and concrete details when mentioned.

5. **Note what's NOT being discussed** - Sometimes the silence is informative.

6. **End with "What to Watch"** - 2-3 things to monitor in the coming day/week.

## Tone
- Confident but not arrogant
- Dense with information, no filler
- Written for someone who already understands crypto/markets
- Occasional dry wit is fine, but substance over style

## Format
Your response MUST follow this exact structure:

SUBJECT: [Your punchy subject line here]

---

[Newsletter body in markdown, 400-600 words]

## What to Watch

- [Item 1]
- [Item 2]
- [Item 3]

---

## Sources
You'll receive tweets grouped by author. Each tweet includes engagement metrics (likes) - higher engagement often (but not always) indicates more signal. Tweets are ordered newest first.`;

export function buildUserPrompt(tweets: GroupedTweets, dateRange: string): string {
  const tweetSections = Object.entries(tweets)
    .map(([handle, handleTweets]) => {
      const tweetList = handleTweets
        .map((t) => {
          let line = `- [${t.likes} likes] ${t.content}`;
          if (t.quoted_tweet_content) {
            line += `\n  > Quoting: "${t.quoted_tweet_content}"`;
          }
          if (t.thread_position && t.thread_position > 1) {
            line = `- [thread ${t.thread_position}] ${t.content}`;
          }
          return line;
        })
        .join('\n');
      
      return `## @${handle}\n${tweetList}`;
    })
    .join('\n\n');

  return `Generate today's briefing based on tweets from ${dateRange}.

${tweetSections}

Write the newsletter following the exact format specified (SUBJECT line, then body, then What to Watch):`;
}

export function parseNewsletterResponse(response: string): { subject: string; content: string } {
  // Extract subject line
  const subjectMatch = response.match(/^SUBJECT:\s*(.+)$/m);
  const subject = subjectMatch?.[1]?.trim() || 'Your Daily Briefing';
  
  // Remove the SUBJECT line and any leading --- from content
  let content = response
    .replace(/^SUBJECT:\s*.+$/m, '')
    .replace(/^---\s*$/m, '')
    .trim();
  
  // If content starts with ---, remove it
  if (content.startsWith('---')) {
    content = content.substring(3).trim();
  }
  
  return { subject, content };
}
